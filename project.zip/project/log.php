
<!DOCTYPE html>
<html>
<head>
  <title>Home</title>
  <link rel="stylesheet" type="text/css" href="style2.css">

  </head>
<body>
	<?php include('header.php') ?>
	 <?php include 'customerpage.php';?>

</body>
</html>
