<?php 

// Change Info From Here

$epay_url = "https://uat.esewa.com.np/epay/main";
$pid = "ThuloTech1234";
$successurl = "http://localhost/tryesewa/success.php";
$failedurl = "http://localhost/tryesewa/failed.php";
$merchant_code = "EPAYTEST"; 
$fraudcheck_url = "https://uat.esewa.com.np/epay/transrec";

// For Amount Check
$actualamount = 1000;

?>