<?php
echo "<h1> Payment Failed";

?>
<a href="http://localhost/tryesewa">Goto Homepage</a>