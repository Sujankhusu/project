<!DOCTYPE html>
<html>
<head>
<style>
	h3{
		color: white; font-weight: bold;
    font-size: 2vw;"
	}
	p{color: white; font-weight: bold;
    font-size: 20px;

	}
</style>

</head>
<body>
	 <footer style="background-color: #4e4747;padding: 10vw";>
	 	<<h3>Future Cinemas</h3>
	 	<p>XYZ,Nepal<br>
	 		futurecinemas@gmail.com<br>
	 		+9771234567890

	 		
	 	</p>
    <p class="pull-right"><a href="#">Back to top</a></p>
    

  </div>
		
</footer>
</body>
</html>
