<?php
echo "<h1> Payment Failed";

?>
<a href="http://localhost/project">Goto Homepage</a>