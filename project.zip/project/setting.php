<?php 

// Change Info From Here

$epay_url = "https://uat.esewa.com.np/epay/main";
$pid = "ThuloTech1237";
$successurl = "http://localhost/project/success.php";
$failedurl = "http://localhost/project/failed.php";
$merchant_code = "EPAYTEST"; 
$fraudcheck_url = "https://uat.esewa.com.np/epay/transrec";

// For Amount Check
$actualamount = 1000;

?>