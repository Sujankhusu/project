<?php 
include_once 'header.php'; 

include 'setting.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ticket</title>
	<link rel="stylesheet" type="text/css" href="css/customerPanel.css">

	

	<style type="text/css">
		.boxStyle{width: 100%;
			border: 1px solid #ccc;
			background: #FFF;
			margin: 0 0 5px;
			padding: 10px;
			font-style: normal;
			font-variant-ligatures: normal;
			font-variant-caps: normal;
			font-variant-numeric: normal;
			font-weight: 400;
			font-stretch: normal;
			font-size: 12px;
			line-height: 16px;
			font-family: Roboto, Helvetica, Arial, sans-serif;
			
		}
	</style>

</head>
<body>

	<?php 
	$movieId=$_SESSION['movieId'];

	$date=$_POST['date'];
	
	$time=$_POST['timeSlot'];
	
	$theater=$_POST['theater'];

	
	$username=$_SESSION['username'];
	
	$showOrder="";
	$seatnumber="";//id of reducing seat
	//seat counting
	$sql="select count(seatnumber) from hall2 where name='".$username."';";
	$result=mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result);
	$seatCount=$row[0];
	$seatCountnum=intval($seatCount);  

	     $res=$conn->query("select * from hall2  where name='".$username."';");
          while ($row=$res->fetch_object()) {
          	$seatnumber.=$row->seatnumber.",";
	}
	$movieIdentity=$conn->query("select * from movielist where movieId=$movieId;");
	$row=$movieIdentity->fetch_object();
$movieName=$row->Name;	

    $user=$username;
    $tseat=$seatCount;
    $amt=$seatCount*300;
    $txamt=$amt*0.13;
    $pdc=0;
    $psc=$amt*0.01;
    $tamt=$amt+$txamt+$psc+$pdc;

    $sqli = "INSERT INTO esewa (username, t_seat, amt, tx_amt, psd, pdc, t_amt) VALUES ('$user', '$tseat', '$amt', '$txamt', '$psc', '$pdc' ,'$tamt')";
	if ($conn->query($sqli) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sqli . "<br>" . $conn->error;
}

?>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
			<div class="panel panel-info">
				<div class="panel-heading">
					<h3 class="panel-title">
						<?php 


							//$_SESSION['movieId']="";

						echo "".$movieName;
						?>

					</h3>
				</div>
				<div class="panel-body">
					<div class="row">
						<div class="col-md-4 col-lg-4 " align="center">
							<img alt="User Pic" src=<?php echo '"image/'.$row->image.'"';?> class="img-responsive"> 
						</div>
						<div class=" col-md-8 col-lg-8 "> 
							<table class="table table-user-information">
								<tbody>

									<tr>
										<td><strong>Date </strong></td>
										<td><?php echo "".$date ?> </td>
									</tr>
									<tr>
										<td><strong>Movie Name </strong></td>
										<td><?php echo "".$row->Name;?> </td>
									</tr>
									<tr>
										<td><strong>Time </strong></td>
										<td><?php echo "". $time?></td>
									</tr>
									<tr>
										<td><strong>Movie Name </strong></td>
										<td><?php echo "". $theater?></td>
									</tr>
									<tr>
										<td><strong>Seat Booked </strong></td>
										<td><?php 
										echo "$seatCount";?> </td>
									</tr>
										<tr>
										<td><strong>Seat number </strong></td>
										<td><?php 
										echo "$seatnumber";?> </td>
									</tr>
									<tr>
										<td><strong>Ticket Price </strong></td>
										<td> <?php $ticketprice=$seatCount*300;
										echo $ticketprice?> </td>
									</tr>
								</table>
								<table>
									
										<tr><td><strong>Payment Method</strong>
										<select>
											<option>eSewa</option>
											<option>fonePay</option>
											<option>Debit Card</option>
										</select></td>

										<tr>
											<td colspan="2" width="100%">
												
												<form action=<?php echo $epay_url?> method="POST">
												    <input value="1000" name="tAmt" type="hidden">
												    <input value="900" name="amt" type="hidden">
												    <input value="50" name="txAmt" type="hidden">
												    <input value="20" name="psc" type="hidden">
												    <input value="30" name="pdc" type="hidden">
												    <input value=<?php echo $merchant_code?>  name="scd" type="hidden">
												    <input value="<?php echo $pid?>" name="pid" type="hidden">
												    <input value=<?php echo $successurl?> type="hidden" name="su">
												    <input value=<?php echo $failedurl?> type="hidden" name="fu">
												    <input value="Confirm & Buy Ticket" type="submit" class="btn btn-primary">
												</form>
											</td>
										</td>
									</form>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


    <!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>

</html>
